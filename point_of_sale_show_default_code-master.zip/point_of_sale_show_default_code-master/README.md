# Show default code in Odoo point of sale

=======
Show default code in Odoo point of sale

